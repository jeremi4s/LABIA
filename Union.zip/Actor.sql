﻿INSERT INTO public."Actor"(
            "Name", "ID")
    VALUES ('Juan', 2);
